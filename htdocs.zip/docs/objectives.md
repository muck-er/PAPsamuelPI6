# PAP

# PLANOS DE TREINO:

1) - Objetivos por utilizador
2) - planos de treino consuante o user
3) - Live chat com utilzador (Ajuda/Questões)
4) - tabela de evoluçao
